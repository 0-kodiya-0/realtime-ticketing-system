export interface RequestParams {
  limit?: number;
  skip?: number;
}
