(window as any).global = window;
